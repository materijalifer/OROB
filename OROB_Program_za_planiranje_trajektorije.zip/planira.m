%Trajekto: makro program za planiranje trajektorije 
%troosnog planarnog rotacijskog robota

%Deklarira globalnu varijablu u kojoj su svojstva grafi�kih objekata:
%global TRAJGRAF_PARAMETRI;


prostor = get(popupmenuProstor,'Value');
maximum = get(popupmenuMaximum,'Value');
krug = get(checkboxKruznica,'Value');
zadano = get(popupmenuParametri,'Value');
datoteka = get(editDatoteka,'String');


%Bri�e i zatvara grafi�ki prozor:
clf reset;
close;

%U ovisnosti o odabranom pozivaju se potrebne procedure za zadavanje ulaznih podataka
%Ako je odabrano kori�tenje preddefiniranih vrijednosti:
if zadano == 1
	%Ako to�ke ne le�e na kru�nici:
	if krug == 0
		%Ako je maximum na trajektoriji:
		if maximum == 1
			ulaz1
		%Ako su maximumi na segmentima:
		elseif maximum == 2
			ulaz1s
		end
	%Ako to�ke le�e na kru�nici:
	elseif krug == 1
		%Ako je maximum na trajektoriji:
		if maximum == 1
			ulaz2
		%Ako su maximumi na segmentima:
		elseif maximum == 2
			ulaz2s
		end
	end
%Ako je odabrano kori�tenje unesenih vrijednosti:
elseif zadano == 2
	%Ako to�ke ne le�e na kru�nici:
	if krug == 0
		%Ako je maximum na trajektoriji:
		if maximum == 1
			unostraj;
		%Ako su maximumi na segmentima:
		elseif maximum == 2
			unosseg;
		end
	%Ako to�ke le�e na kru�nici:
	elseif krug == 1
		%Ako je maximum na trajektoriji:
		if maximum == 1
			unostraj;
		%Ako su maximumi na segmentima:
		elseif maximum == 2
			unosseg;
		end
	end
%Ako je odabrano u�itavanje vrijednosti iz datoteke:
elseif zadano == 3
		eval(['load ' datoteka]);
end

%Provjerava da li zadane to�ke le�e u podru�ju dohvata robota:
tockeok = [0 0 0 0 0 0 0]'
for i = 1:7
	eval(['pom = w' num2str(i) ';'])
	pom1 = sqrt((pom(1)^2) + (pom(2)^2));
	if (pom1 <=  a1 + a2) & (pom1 >= a1 - a2), tockeok(i) = 1; end
end
%Ako su sve to�ke u podru�ju dohvata robota:
if tockeok == [1 1 1 1 1 1 1]'
	%U ovisnosti o odabiru pokre�e procedure za interpolaciju putanje:
	%Ako je odabran prostor varijabli zglobova:
	if prostor == 1
		%Ako je maximum na trajektoriji:
		if maximum == 1
			radq
		%Ako su maximumi na segmentima:
		elseif maximum == 2
			radqs
		end
	%Ako je odabran prostor konfiguracije alata:
	elseif prostor == 2
		%Ako je maximum na trajektoriji:
		if maximum == 1
			radw
		%Ako su maximumi na segmentima:
		elseif maximum == 2
			radws
		end
	end
% Ako sve to�ke ne le�e u podru�ju dohvata robota:
else 
	disp('Bar jedna od zadanih to�aka ne le�i u podru�ju dohvata robota')
	disp('Provjerite zadane to�ke i zadane dimenzije robota !')
end

	