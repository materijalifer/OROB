function B1 = f4(v1,v2,dv1,dv2,t2)
%B1 = f4(v1,v2,dv1,dv2,t2)
%Funkcija za generiranje matrice B1
%Varijabla v: q ili w (vektor varijabli zglobova ili
%vektor konnfiguracije alata)

vk1=[v1 v2 dv1 dv2];  pom1=[1 0 0 0]';
pom2=[0 0 0 0]';  pom3=[0 0 0 0]';
pom4=[-4/(t2^3) 4/(t2^3) 0 -1/(t2^2)]';
pom5=[3/(t2^4) -3/(t2^4) 0 1/(t2^3)]';
tk1=[pom1 pom2 pom3 pom4 pom5];  
B1=vk1*tk1;

