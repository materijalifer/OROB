%Procedura ulaz1s:
%Zadavanje potrebnih vrijednosti za planiranje trajektorije
%kada se ne crta krug, pri �emu su maximumi kutnih brzina
%ili ubrzanja dozvoljeni na svakom segmentu trajektorije

disp(' ')
disp(' ')
disp('ZADAVANJE POTREBNIH VRIJEDNOSTI')
disp('   ZA PLANIRANJE TRAJEKTORIJE  ')
disp('     (KADA SE NE CRTA KRUG)    ')
disp('  PRI CEMU SU MAKSIMUMI KUTNIH ')
disp(' BRZINA ILI UBRZANJA DOZVOLJENI')
disp('NA SVAKOM SEGMENTU TRAJEKTORIJE')
a1=0.3;
a2=0.2; 
d3=0.1;
w1=[0.5 0 0 0 0 1]';
w2=[0.45 0.05 0 0 0 1.086904]';
w3=[0.4 0.1 0 0 0 1.1813604]';
w4=[0.35 0.15 0 0 0 1.2840254]';
w5=[0.3 0.2 0 0 0 1.3956124]';
w6=[0.25 0.25 0 0 0 1.5168968]';
w7=[0.2 0.3 0 0 0 1.6487213]';
vgr1=[1.7453 1.5708 1.3963]';
vgr2=vgr1;  vgr3=vgr1;  vgr4=vgr1;
vgr5=vgr1;  vgr6=vgr1;
agr1=[0.7854 0.8727 0.6981]';
agr2=agr1; agr3=agr1; agr4=agr1;
agr5=agr1; agr6=agr1;
krug=0;
disp(' ')
disp(' ')
