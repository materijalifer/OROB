function mqi = f7n(Bi,ti,a1,a2)
%mqi = f7n(Bi,ti,a1,a2)
%Funkcija za trazenje maksimuma dq1(t) i dq6(t)
%te ddq1(t) i ddq6(t) 
%Ulaz su vremenske funkcije u prostoru konfiguracije alata

B0i=Bi(:,1); B1i=Bi(:,2); B2i=Bi(:,3);
B3i=Bi(:,4); B4i=Bi(:,5);
dt=ti/100; 
max1=[0 0 0]'; max2=[0 0 0]';
min1=[0 0 0]'; min2=[0 0 0]';
t=0; 
w=B0i; 
qstari=f0(w,a1,a2); 
t=t+dt;
w=B0i+B1i*t+B2i*(t^2)+B3i*(t^3)+B4i*(t^4);
qnovi=f0(w,a1,a2); 
dqstari=(qnovi-qstari)/dt;
qstari=qnovi; 
t=t+dt;
while t<(ti+dt-dt*0.001)
   	w=B0i+B1i*t+B2i*(t^2)+B3i*(t^3)+B4i*(t^4);...
   	qnovi=f0(w,a1,a2); 
	dqnovi=(qnovi-qstari)/dt;
   	ddq=(dqnovi-dqstari)/dt;
   	for j=1:3
		if dqnovi(j,1)>max1(j,1), max1(j,1)=dqnovi(j,1); end
		if dqnovi(j,1)<min1(j,1), min1(j,1)=dqnovi(j,1); end
		if ddq(j,1)>max2(j,1), max2(j,1)=ddq(j,1); end
		if ddq(j,1)<min2(j,1), min2(j,1)=ddq(j,1); end
	end
   	qstari=qnovi; dqstari=dqnovi; 
	t=t+dt; 
end
for j=1:3
   	if max1(j,1)>(min1(j,1))*(-1)
      		mdqi(j,1)=max1(j,1);
   	else 
		mdqi(j,1)=(min1(j,1))*(-1); 
	end
   	if max2(j,1)>(min2(j,1))*(-1)
      		mddqi(j,1)=max2(j,1);
   	else 
		mddqi(j,1)=(min2(j,1))*(-1); 
	end 
end
mqi=[mdqi mddqi];

