%Procedura sl4qqs: usporedba ubrzanja zglobova pri planiranju trajektorije u prostoru
%varijabli zglobova s jednim maksimumom na trajektoriji i maksimumima na svakom
%segmentu trajektorije

disp(' ')
disp(' ')
disp('     USPOREDBA METODA PLANIRANJA TRAJEKTORIJE     ')
disp('          U PROSTORU VARIJABLI ZGLOBOVA           ')
disp('PRI �EMU SU MAKSIMUMI KUTNIH BRZINA ILI UBRZANJA :')
disp('(1) DOZVOLJENI NA SAMO JEDNOM MJESTU TRAJEKTORIJE ')
disp('(2) DOZVOLJENI NA SVAKOM SEGMENTU TRAJEKTORIJE    ')
disp(' ')
disp(' ')
disp('GRAFI�KI PRIKAZ VREMENSKE OVISNOSTI UBRZANJA ZGLOBOVA')
disp('         ZA TROOSNI PLANARNI ROTACIJSKI ROBOT         ')
disp(' ')
clear
disp(' ')
load 'rez3q'
load 'rez3qs'

hold off
figure (4)
set(gcf, 'Name', 'q - prostor: 1 maksimum, maksimumi na segmentima');
plot(vrijemeq, ubrzanjaq(:,1), 'y-', vrijemeq, ubrzanjaq(:,2), 'r-', vrijemeq, ubrzanjaq(:,3), 'b-')
xlabel('Vrijeme [s]')
ylabel('Ubrzanja [rad/s^2]')
title('q: ______  qs:__  __  __   1. zglob: �uto   2. zglob: crveno   3. zglob: plavo')
hold on
plot(vrijemeqs, ubrzanjaqs(:,1), 'y--', vrijemeqs, ubrzanjaqs(:,2), 'r--', vrijemeqs, ubrzanjaqs(:,3), 'b--')
clear 
