function A = f3(v1,v2,v3,v4,v5,v6,v7,t2,t3,t4,t5,t6,t7)
%A = f3(v1,v2,v3,v4,v5,v6,v7,t2,t3,t4,t5,t6,t7)
%Funkcija za generiranje matrice A koja slu�i za
%izra�unavanje brzina na po�etku segmenata trajektorije
%Varijabla v: q ili w (vektor varijabli zglobova ili vektor
%konfiguracije alata na po�etku segmenta)

pom1=6*(v2-v1)/(t2^2)+3*(v3-v2)/(t3^2);
pom2=3*((t3^2)*(v4-v3)+(t4^2)*(v3-v2))/(t3*t4);
pom3=3*((t4^2)*(v5-v4)+(t5^2)*(v4-v3))/(t4*t5);
pom4=3*((t5^2)*(v6-v5)+(t6^2)*(v5-v4))/(t5*t6);
pom5=3*(v6-v5)/(t6^2)+6*(v7-v6)/(t7^2);
A=[pom1 pom2 pom3 pom4 pom5];

