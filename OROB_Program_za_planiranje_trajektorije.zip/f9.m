function mddqi = f9(Bi,t2)
% mddqi=f9(Bi,t2)
% Funkcija za trazenje maksimuma ddq1(t) i ddq6(t),
% maximuma akceleracija na 1. i  6. segmentu

B2i=Bi(:,3);  B3i=Bi(:,4);  B4i=Bi(:,5);
t=0; 
dt=t2/100; 
maxi=[0 0 0]'; 
mini=[0 0 0]';
while t < (t2+dt-dt*0.000001)
	ddqi=2*B2i+6*B3i*t+12*B4i*(t^2);
	for j=1:3
		if ddqi(j,1) > maxi(j,1), maxi(j,1)=ddqi(j,1); end
		if ddqi(j,1) < mini(j,1), mini(j,1)=ddqi(j,1); end
	end
	 t=t+dt; 
end
for j=1:3
	if maxi(j,1) > (mini(j,1))*(-1)
		mddqi(j,1)=maxi(j,1);
	else 
		mddqi(j,1)=(mini(j,1))*(-1); 
	end
end

