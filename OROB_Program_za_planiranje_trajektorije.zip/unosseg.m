%Procedura unosseg: unos ulaznih varijabli za interpolaciju
%trajektorije s maximumom na svakom segmentu trajektorije

dalje = 0;
while dalje == 0
	a1 = input('Du�ina prvog segmenta (a1): ');
	if a1 > 0
		dalje = 1;
	end
end

dalje = 0;
while dalje == 0
	a2 = input('Du�ina drugog segmenta (a2): ');
	if a2 > 0
		dalje = 1;
	end
end

dalje = 0;
while dalje == 0
	d3 = input('Du�ina tre�eg segmenta (d3): ');
	if d3 > 0
		dalje = 1;
	end
end

for i = 1:6
	dalje = 0;
	while dalje == 0
		istr = num2str(i);
		str = ['Vektor maksimalnih brzina za ' istr '. segment (vgr' istr '): '];
		pom = input(str);
		if size(pom) == [3 1], dalje = 1; end
	end
	eval(['vgr' istr ' = pom;'])
end

for i = 1:6
	dalje = 0;
	while dalje == 0
		istr = num2str(i);
		str = ['Vektor maksimalnih ubrzanja za ' istr '. segment (agr' istr '): '];
		pom = input(str);
		if size(pom) == [3 1], dalje = 1; end
	end
	eval(['agr' istr ' = pom;'])
end

for i = 1:7
	dalje = 0;
	while dalje == 0
		istr = num2str(i);
		str = ['Unesite ' istr '. to�ku trajektorije (w' istr '): '];
		pom = input(str);
		if size(pom) == [6 1], dalje = 1; end
	end
	eval(['w' istr ' = pom;'])
end

if krug == 1 
	dalje = 0;
	while dalje == 0
		r = input('Polumjer kru�nice (r): ');
		if r > 0
			dalje = 1;
		end
	end
	
	dalje = 0;
	while dalje == 0
		xs = input('Apscisa sredi�ta (xs): ');
		if abs(xs) < sqrt(a1^2+a2^2)
			dalje = 1;
		end
	end

	dalje = 0;
	while dalje == 0
		ys = input('Ordinata sredi�ta (ys): ');
		if abs(ys) < sqrt(a1^2+a2^2)
			dalje = 1;
		end
	end
end

%izbor = menu('�elite li unesene podatke spremiti u datoteku?', 'da', 'ne');

dalje = 0;
while dalje == 0
	unos = input('�elite li unesene podatke spremiti u datoteku? (d/n): ','s');
	if ((unos == 'd') | (unos == 'n')), dalje = 1; end
end

if unos == 'd'
	dalje = 0;
	while dalje == 0
		datoteka = input('Unesite ime datoteke: ', 's');
		if length(datoteka) > 0 & length(datoteka) <= 12, dalje = 1; end
	end
	if krug == 0
		eval(['save ' datoteka ' a1 a2 d3 w1 w2 w3 w4 w5 w6 w7 vgr1 vgr2 vgr3 vgr4 vgr5 vgr6 agr1 agr2 agr3 agr4 agr5 agr6 krug'])
	else
		eval(['save ' datoteka ' a1 a2 d3 w1 w2 w3 w4 w5 w6 w7 vgr1 vgr2 vgr3 vgr4 vgr5 vgr6 agr1 agr2 agr3 agr4 agr5 agr6 krug r xs ys'])
	end
end
