%Procedura sl3qqs: usporedba brzina zglobova pri planiranju trajektorije u prostoru
%varijabli zglobova s jednim maksimumom na trajektoriji i maksimumima na svakom
%segmentu trajektorije

disp(' ')
disp(' ')
disp('     USPOREDBA METODA PLANIRANJA TRAJEKTORIJE     ')
disp('          U PROSTORU VARIJABLI ZGLOBOVA           ')
disp('PRI �EMU SU MAKSIMUMI KUTNIH BRZINA ILI UBRZANJA :')
disp('(1) DOZVOLJENI NA SAMO JEDNOM MJESTU TRAJEKTORIJE ')
disp('(2) DOZVOLJENI NA SVAKOM SEGMENTU TRAJEKTORIJE    ')
disp(' ')
disp(' ')
disp('GRAFI�KI PRIKAZ VREMENSKE OVISNOSTI BRZINA ZGLOBOVA')
disp('         ZA TROOSNI PLANARNI ROTACIJSKI ROBOT         ')
disp(' ')
clear
disp(' ')
load 'rez2q'
load 'rez2qs'

hold off
figure (3)
set(gcf, 'Name', 'q - prostor: 1 maksimum, maksimumi na segmentima');
plot(vrijemeq, brzineq(:,1), 'y-', vrijemeq, brzineq(:,2), 'r-', vrijemeq, brzineq(:,3), 'b-')
xlabel('Vrijeme [s]')
ylabel('Brzine [rad/s]')
title('q: ______  qs:__  __  __   1. zglob: �uto   2. zglob: crveno   3. zglob: plavo')
hold on
plot(vrijemeqs, brzineqs(:,1), 'y--', vrijemeqs, brzineqs(:,2), 'r--', vrijemeqs, brzineqs(:,3), 'b--')
clear 
