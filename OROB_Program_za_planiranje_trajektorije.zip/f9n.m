function mdq = f9n(mdq1,mdq2,mdq3,mdq4,mdq5,mdq6)
% mdq=f9n(mdq1,mdq2,mdq3,mdq4,mdq5,mdq6)
% Funkcija za tra�enje ukupnog maksimuma dq(t) i ddq(t)

maxi=mdq1;
for j=1:3
	if mdq2(j,1)>maxi(j,1), maxi(j,1)=mdq2(j,1); end
	if mdq3(j,1)>maxi(j,1), maxi(j,1)=mdq3(j,1); end
	if mdq4(j,1)>maxi(j,1), maxi(j,1)=mdq4(j,1); end
	if mdq5(j,1)>maxi(j,1), maxi(j,1)=mdq5(j,1); end
	if mdq6(j,1)>maxi(j,1), maxi(j,1)=mdq6(j,1); end
end 
mdq=maxi(:,1);

