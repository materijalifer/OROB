%Procedura sl1qqs: Usporedba isplaniranih trajektorija u prostoru
%varijabli zglobova s jednim maksimumom na trajektoriji i s maksimumima na
%svakom segmentu trajektorije

disp(' ')
disp(' ')
disp('     USPOREDBA METODA PLANIRANJA TRAJEKTORIJE     ')
disp('          U PROSTORU VARIJABLI ZGLOBOVA           ')
disp('PRI �EMU SU MAKSIMUMI KUTNIH BRZINA ILI UBRZANJA :')
disp('(1) DOZVOLJENI NA SAMO JEDNOM MJESTU TRAJEKTORIJE ')
disp('(2) DOZVOLJENI NA SVAKOM SEGMENTU TRAJEKTORIJE    ')
disp(' ')
disp(' ')
disp('      GRAFI�KI PRIKAZ ZADANIH TO�AKA,      ')
disp('�ELJENE I APROKSIMIRANE PUTANJE U XY RAVNINI')
disp('    ZA TROOSNI PLANARNI ROTACIJSKI ROBOT    ')
disp(' ')
disp('Samo trenutak  molim')
clear
disp(' ')
load 'rez4q'
load 'rez4qs';
wx(:,1)=wxq(:,1); wx(:,2)=wxq(:,2); wx(:,3)=wxqs(:,2);
wy(:,1)=wyq(:,1); wy(:,2)=wyq(:,2); wy(:,3)=wyqs(:,2);
%Prvi stupac matrice wx: Niz �eljenih x koordinata kod planiranja u prostoru varijabli
%zglobova s jednim maksimumom na trajektoriji (a iste bi trebale biti i kod planiranja
%s maksimumima na svakom segmentu, ina�e usporedba nema smisla)
%Drugi stupac matrice wx: Niz x koordinata isplaniranih u prostoru varijabli zglobova
%s jednim maksimumom na trajektoriji
%Tre�i stupac matrice wx: Niz x koordinata isplaniranih u prostoru varijabli zglobova
%s maksimumom na svakom segmentu
%Sli�no matrica wy

figure(1);
set(gcf, 'Name', 'q - prostor: 1 maksimum, maksimumi na segmentima');
plot(xtoc(1), ytoc(1), 'cx', xtoc(2), ytoc(2), 'cx', xtoc(3), ytoc(3), 'cx', xtoc(4), ytoc(4), 'cx', ...
	xtoc(5), ytoc(5), 'cx', xtoc(6), ytoc(6), 'cx', xtoc(7), ytoc(7), 'cx')
hold on 
plot(wx(:,1), wy(:,1), 'y:', wx(:,2), wy(:,2), 'b--', wx(:,3), wy(:,3), 'r-')
axis('equal')
grid off
xlabel('x - os')
ylabel('y - os')
title('�eljeno: _  _  _(�uto)   1 maksimum: __  __  __ (plavo)   maksimumi: ______ (crveno)')
clear 
