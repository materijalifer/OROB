%Procedura sl2qsws: usporedba zakreta zglobova pri planiranju trajektorije u prostoru
%varijabli zglobova i prostoru konfiguracije alata pri �emu su maksimumi
%kutnih brzina ili ubrzanja dozvoljeni na svakom segmentu trajektorije

disp(' ')
disp(' ')
disp('          USPOREDBA METODA PLANIRANJA TRAJEKTORIJE          ')
disp('U PROSTORU VARIJABLI ZGLOBOVA I PROSTORU KONFIGURACIJE ALATA')
disp('      PRI �EMU SU MAKSIMUMI KUTNIH BRZINA ILI UBRZANJA      ')
disp('       DOZVOLJENI NA SVAKOM SEGMENTU  TRAJEKTORIJE        ')
disp(' ')
disp(' ')
disp('GRAFI�KI PRIKAZ VREMENSKE OVISNOSTI VARIJABLI ZGLOBOVA')
disp('         ZA TROOSNI PLANARNI ROTACIJSKI ROBOT         ')
disp(' ')
clear
disp(' ')
load 'rez1qs'
load 'rez1ws'

hold off
figure (2)
set(gcf, 'Name', 'Usporedba: w - prostor, q - prostor, maximumi na segmentima');
plot(vrijemeqs, qqs(:,1), 'y-', vrijemeqs, qqs(:,2), 'r-', vrijemeqs, qqs(:,3), 'b-')
xlabel('Vrijeme [s]')
ylabel('Zakreti [rad]')
title('q: ______  w:__  __  __   1. zglob: �uto   2. zglob: crveno   3. zglob: plavo')
hold on
plot(vrijemews, qws(:,1), 'y--', vrijemews, qws(:,2), 'r--', vrijemews, qws(:,3), 'b--')
clear 
