function mdqi = f7(Bi,t2)
%mdqi = f7(Bi,t2)
%Funkcija za trazenje maksimuma dq1(t) i dq6(t)
%(maksimuma brzina na prvom ili zadnjem segmentu)

B1i=Bi(:,2); B2i=Bi(:,3); B3i=Bi(:,4); B4i=Bi(:,5);
t=0; 
dt=t2/100; 
maxi=[0 0 0]'; 
mini=[0 0 0]';
while  t<(t2+dt-dt*0.000001)
	dqi=B1i+2*B2i*t+3*B3i*(t^2)+4*B4i*(t^3);
   	for j=1:3
		if dqi(j,1)>maxi(j,1), maxi(j,1)=dqi(j,1); end
		if dqi(j,1)<mini(j,1), mini(j,1)=dqi(j,1); end
	end
	t=t+dt; 
end
for j=1:3
	if maxi(j,1)>(mini(j,1))*(-1)
      		mdqi(j,1)=maxi(j,1);
   	else 
		mdqi(j,1)=(mini(j,1))*(-1);
	 end
 end

