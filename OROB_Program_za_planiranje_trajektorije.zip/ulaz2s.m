%Procedura ulaz2s:
%Zadavanje potrebnih vrijednoosti za planiranje trajektorije
%(kada se crta krug), pri �emu su maksimumi kutnih
%brzina ili ubrzanja dozvoljeni na svakom segmenntu
%trajektorije

disp(' ') 
disp(' ')
disp('ZADAVANJE POTREBNIH VRIJEDNOSTI')
disp('   ZA PLANIRANJE TRAJEKTORIJE  ')
disp('      (KADA SE CRTA KRUG)      ')
disp('  PRI CEMU SU MAKSIMUMI KUTNIH ')
disp(' BRZINA ILI UBRZANJA DOZVOLJENI')
disp('NA SVAKOM SEGMENTU TRAJEKTORIJE')
a1=0.3;
a2=0.2; 
d3=0.1;
w1=[0.3 0.3 0 0 0 1]';
w2=[0.38660254 0.25 0 0 0 1.086904]';
w3=[0.38660254 0.15 0 0 0 1.1813604]';
w4=[0.3 0.1 0 0 0 1.2840254]';
w5=[0.21339746 0.15 0 0 0 1.3956124]';
w6=[0.21339746 0.25 0 0 0 1.5168968]';
w7=[0.3 0.3 0 0 0 1.6487213]';
vgr1=[1.7453 1.5708 1.3963]';
vgr2=vgr1;  vgr3=vgr1;  vgr4=vgr1;
vgr5=vgr1;  vgr6=vgr1;
agr1=[0.7854 0.8727 0.6981]';
agr2=agr1;  agr3=agr1;  agr4=agr1;
agr5=agr1;  agr6=agr1;
krug=1; 
 r=0.1;
 xs=0.3;
 ys=0.2;
disp(' ')
disp(' ')


