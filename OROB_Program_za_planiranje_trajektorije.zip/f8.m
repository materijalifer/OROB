function  mdqi = f8(Bi,ti)
% mdqi = f8(Bi,ti)
% Funkcija za trazenje maksimuma dq2(t),...,dq5(t)

B1i=Bi(:,2);  B2i=Bi(:,3);  B3i=Bi(:,4);
t=0; 
dt=ti/100; 
maxi=[0 0 0]'; 
mini=[0 0 0]';
while t < (ti+dt-dt*0.000001)
	dqi=B1i+2*B2i*t+3*B3i*(t^2);...
   	for j=1:3
		if dqi(j,1) > maxi(j,1), maxi(j,1)=dqi(j,1); end
		if dqi(j,1) < mini(j,1), mini(j,1)=dqi(j,1); end
   	end
	t=t+dt;
 end
for j=1:3
   	if maxi(j,1) > (mini(j,1))*(-1)
		mdqi(j,1)=maxi(j,1);
	else 
		mdqi(j,1)=(mini(j,1))*(-1); 
	end 
end
