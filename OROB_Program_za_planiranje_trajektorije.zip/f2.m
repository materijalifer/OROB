function M = f2(t2,t3,t4,t5,t6,t7)
%M = f2(t2,t3,t4,t5,t6,t7)
%Funkcija za generiranje matrice M koja slu�i
%za ra�unanje brzina na po�ecima segmenata
%trajektorije

pom1=[3/t2+2/t3 1/t3 0 0 0]';
pom2=[t4 2*(t3+t4) t3 0 0]';
pom3=[0 t5 2*(t4+t5) t4 0]';
pom4=[0 0 t6 2*(t5+t6) t5]';
pom5=[0 0 0 1/t6 2/t6+3/t7]';
M=[pom1 pom2 pom3 pom4 pom5];

