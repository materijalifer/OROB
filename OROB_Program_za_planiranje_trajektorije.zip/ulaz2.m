%Procedura ulaz2: 
%Zadavanje potrebnih vrijednosti za planiranje
%trajektorije (kada se crta krug), pri �emu
%su maksimumi kutnih brzina ili ubrzanja
%dozvoljeni na samo jednom mjestu trajektorije

disp(' ')
disp(' ')
disp(' ZADAVANJE POTREBNIH VRIJEDNOSTI  ')
disp('    ZA PLANIRANJE TRAJEKTORIJE    ')
disp('       (KADA SE CRTA KRUG)        ')
disp('   PRI CEMU SU MAKSIMUMI KUTNIH   ')
disp('  BRZINA ILI UBRZANJA DOZVOLJENI  ')
disp('NA SAMO JEDNOM MJESTU TRAJEKTORIJE')
a1=0.3;
a2=0.2;
d3=0.1;
w1=[0.3 0.3 0 0 0 1]';
w2=[0.3866 0.25 0 0 0 1.086904]';
w3=[0.3866 0.15 0 0 0 1.1813604]';
w4=[0.3 0.1 0 0 0 1.2840254]';
w5=[0.2134 0.15 0 0 0 1.3956124]';
w6=[0.2134 0.25 0 0 0 1.5168968]';
w7=[0.3 0.3 0 0 0 1.6487213]';
vgr=[1.7453 1.5708 1.3963]';
agr=[0.7854 0.8727 0.6981]';
krug=1;
 r=0.1; 
xs=0.3;
ys=0.2;
disp(' ')
disp(' ')
