%Procedura radws: Innterpolacija putanje u prostoru konfiguracije alata
%polinomima tre�eg i �etvrtog stupnja za troosni planarni rotacijski
%robot pri �emu su maksimumi kutnih brzina ili ubrzanja dozvoljeni
%na svakom segmentu trajektorije

disp(' ')
disp(' ')
disp('INTERPOLACIJA PUTANJE U PROSTORU KONFIGURACIJE ALATA')
disp('        POLINOMIMA TRE�EG I �ETVRTOG STUPNJA        ')
disp('        ZA TROOSNI PLANARNI ROTACIJSKI ROBOT        ')
disp(' PRI �EMU SU MAKSIMUMI KUTNIH BRZINA ILI UBRZANJA   ')
disp('    DOZVOLJENI NA SVAKOM SEGMENTU TRAJEKTORIJE      ')
disp(' ')
disp('Zadane varijable:')
disp(' ')
disp('Duljine segmenata ([m]):'), a1, a2, d3
disp(' ')
disp('To�ke pomo�u vektora konfiguracije alata:')
w1, w2, w3, w4, w5, w6, w7
disp(' ')
disp('Ograni�enja brzina zglobova po segmentima ([rad/s]):')
vgr1, vgr2, vgr3, vgr4, vgr5, vgr6
disp(' ')
disp('Ograni�enja ubrzanja zglobova po segmentima ([rad/s^2]):')
agr1, agr2, agr3, agr4, agr5, agr6
disp(' ')
disp('Crtanje kruga (krug=0 NE i krug=1 DA):'), krug
if krug==1
	disp(' ')
	disp('Polumjer kruga ([m]):'), r
	disp(' ')
	disp('Sredi�te kruga ([m]):'), xs, ys
end

disp(' ')
disp(' ')
disp('PLANIRANJE TRAJEKTORIJE U PROSTORU KONFIGURACIJE ALATA')
disp('         ZA TROOSNI PLANARNI ROTACIJSKI ROBOT         ')
disp('  PRI �EMU SU MAKSIMUMI KUTNIH BRZINA ILI UBRZANJA    ')
disp('     DOZVOLJENI NA SVAKOM SEGMENTU TRAJEKTORIJE       ')
disp(' ')
disp('Kori�tene funkcije:')
help f0
help f1
help f2
help f3
help f4
help f5
help f6
help f7n
help f8n
help f9n
help f10n
disp(' ')
disp('Ra�unanje parametri�kih vremena:')
t2=f1(w1,w2), t3=f1(w2,w3), t4=f1(w3,w4)
t5=f1(w4,w5), t6=f1(w5,w6), t7=f1(w6,w7)

i=0; 
S1=0; S2=0; S3=0; S4=0; S5=0; S6=0; S7=0; S=0;
while abs(1-S)>1e-10
	disp(' ')
	i=i+1;
	disp('Broj iteracije:'), i
	M=f2(t2,t3,t4,t5,t6,t7)
	A=f3(w1,w2,w3,w4,w5,w6,w7,t2,t3,t4,t5,t6,t7)
	disp(' ')
	disp('Brzine u zadanim tockama:')
	dw=A*inv(M)
	dw1=[0 0 0 0 0 0]'
	dw2=dw(:,1)
	dw3=dw(:,2)
	dw4=dw(:,3)
	dw5=dw(:,4)
	dw6=dw(:,5)
	dw7=[0 0 0 0 0 0]'
	disp(' ')
	disp('Koeficijenti za 1. segment:')
	B1=f4(w1,w2,dw1,dw2,t2)
	disp(' ')
	disp('Koeficijenti za 2. segment:')
	B2=f5(w2,w3,dw2,dw3,t3)
	disp(' ')
	disp('Koeficijenti za 3. segment:')
	B3=f5(w3,w4,dw3,dw4,t4)
	disp(' ')
	disp('Koeficijenti za 4. segment:')
	B4=f5(w4,w5,dw4,dw5,t5)
	disp(' ')
	disp('Koeficijenti za 5. segment:')
	B5=f5(w5,w6,dw5,dw6,t6)
	disp(' ')
	disp('Koeficijenti za 6. segment:')
	B6=f6(w6,w7,dw6,dw7,t7)
	disp(' ')
	disp('Maksimumi kutnih brzina ([rad/s]):')
	mq1=f7n(B1,t2,a1,a2);
	mdq1=mq1(:,1)
	mq2=f8n(B2,t3,a1,a2);
	mdq2=mq2(:,1)
	mq3=f8n(B3,t4,a1,a2);
	mdq3=mq3(:,1)
	mq4=f8n(B4,t5,a1,a2);
	mdq4=mq4(:,1)
	mq5=f8n(B5,t6,a1,a2);
	mdq5=mq5(:,1)
	mq6=f7n(B6,t7,a1,a2);
	mdq6=mq6(:,1)
	disp(' ')
	disp('Maksimumi kutnih ubrzanja ([rad/s^2]):')
	mddq1=mq1(:,2)
	mddq2=mq2(:,2)
	mddq3=mq3(:,2)
	mddq4=mq4(:,2)
	mddq5=mq5(:,2)
	mddq6=mq6(:,2)
	disp(' ')
	disp('Ukupni maksimum kutnih brzina ([rad/s]):')
	mdq=f9n(mdq1,mdq2,mdq3,mdq4,mdq5,mdq6)
	disp(' ')
	disp('Ukupni maksimum kutnih ubrzanja ([rad/s^2]):')
	mddq=f9n(mddq1,mddq2,mddq3,mddq4,mddq5,mddq6)
	disp(' ')
	disp('Ograni�enja brzine po segmentima ([rad/s]):')
	vgr1, vgr2, vgr3, vgr4, vgr5, vgr6
	disp(' ')
	disp('Ograni�enja ubrzanja  po segmentima ([rad/s^2]):')
	agr1, agr2, agr3, agr4, agr5, agr6
	disp(' ')
	S31=f10n(mdq1,mddq1,vgr1,agr1);
	S32=f10n(mdq2,mddq2,vgr2,agr2);
	S33=f10n(mdq3,mddq3,vgr3,agr3);
	S34=f10n(mdq4,mddq4,vgr4,agr4);
	S35=f10n(mdq5,mddq5,vgr5,agr5);
	S36=f10n(mdq6,mddq6,vgr6,agr6);
	disp('Faktori normiranja po brzini za sve segmente:')
	Sv1=S31(1,1)
	Sv2=S32(1,1)
	Sv3=S33(1,1)
	Sv4=S34(1,1)
	Sv5=S35(1,1)
	Sv6=S36(1,1)
	disp(' ')
	disp('Faktori normiranja po ubrzanju za sve segmente:')
	Sa1=S31(1,2)
	Sa2=S32(1,2)
	Sa3=S33(1,2)
	Sa4=S34(1,2)
	Sa5=S35(1,2)
	Sa6=S36(1,2)
	disp(' ')
	disp('Ukupni faktori normiranja za sve segmente:')
	S1=S31(1,3)
	S2=S32(1,3)
	S3=S33(1,3)
	S4=S34(1,3)
	S5=S35(1,3)
	S6=S36(1,3)
	disp(' ')
	disp('Nova vremena prijelaza segmenata ([s]):')
	t2=t2*S1
	t3=t3*S2
	t4=t4*S3
	t5=t5*S4
	t6=t6*S5
	t7=t7*S6
	disp(' ')
	disp('Ukupno vrijeme ([s]):')
	Tuk=t2+t3+t4+t5+t6+t7
	if abs(1-S1)<1e-2 & abs(1-S2)<1e-2 & abs(1-S3)<1e-2 & abs(1-S4)<1e-2 & abs(1-S5)<1e-2 & abs(1-S6)<1e-2
		S=1;
	end
end
disp(' ')
disp('Broj iteracija potrebnih za zavr�etak postupka:'), i
disp(' ')
disp('Putanja se prelazi za slijede�i broj sekundi:'), Tuk
disp(' ')
disp('Za grafi�ke prikaze pritisnite tipku')
pause

disp(' ')
disp(' ')
disp('GRAFI�KI PRIKAZ VREMENSKE OVISNOSTI VARIJABLI ZGLOBOVA')
disp('         ZA TROOSNI PLANARNI ROTACIJSKI ROBOT         ')
disp(' ')
disp(' ')
t=0;
k=1;
Tuk=t2+t3+t4+t5+t6+t7;
dt=Tuk/300;
while t<(Tuk+dt*0.01)
	if t>=0 & t<t2
		tp=t;
		vrijeme(k,1)=t;
		w(k,1)=B1(1,1)+B1(1,2)*tp+B1(1,3)*(tp^2)+B1(1,4)*(tp^3)+B1(1,5)*(tp^4);
		w(k,2)=B1(2,1)+B1(2,2)*tp+B1(2,3)*(tp^2)+B1(2,4)*(tp^3)+B1(2,5)*(tp^4);
		w(k,3)=B1(3,1)+B1(3,2)*tp+B1(3,3)*(tp^2)+B1(3,4)*(tp^3)+B1(3,5)*(tp^4);
		w(k,4)=B1(4,1)+B1(4,2)*tp+B1(4,3)*(tp^2)+B1(4,4)*(tp^3)+B1(4,5)*(tp^4);
		w(k,5)=B1(5,1)+B1(5,2)*tp+B1(5,3)*(tp^2)+B1(5,4)*(tp^3)+B1(5,5)*(tp^4);
		w(k,6)=B1(6,1)+B1(6,2)*tp+B1(6,3)*(tp^2)+B1(6,4)*(tp^3)+B1(6,5)*(tp^4);
	end
	if t>=t2 & t<(t2+t3)
		tp=t-t2;
		vrijeme(k,1)=t;
		w(k,1)=B2(1,1)+B2(1,2)*tp+B2(1,3)*(tp^2)+B2(1,4)*(tp^3);
		w(k,2)=B2(2,1)+B2(2,2)*tp+B2(2,3)*(tp^2)+B2(2,4)*(tp^3);
		w(k,3)=B2(3,1)+B2(3,2)*tp+B2(3,3)*(tp^2)+B2(3,4)*(tp^3);
		w(k,4)=B2(4,1)+B2(4,2)*tp+B2(4,3)*(tp^2)+B2(4,4)*(tp^3);
		w(k,5)=B2(5,1)+B2(5,2)*tp+B2(5,3)*(tp^2)+B2(5,4)*(tp^3);
		w(k,6)=B2(6,1)+B2(6,2)*tp+B2(6,3)*(tp^2)+B2(6,4)*(tp^3);
	end
	if t>=(t2+t3) & t<(t2+t3+t4)
		tp=t-t2-t3;
		vrijeme(k,1)=t;
		w(k,1)=B3(1,1)+B3(1,2)*tp+B3(1,3)*(tp^2)+B3(1,4)*(tp^3);
		w(k,2)=B3(2,1)+B3(2,2)*tp+B3(2,3)*(tp^2)+B3(2,4)*(tp^3);
		w(k,3)=B3(3,1)+B3(3,2)*tp+B3(3,3)*(tp^2)+B3(3,4)*(tp^3);
		w(k,4)=B3(4,1)+B3(4,2)*tp+B3(4,3)*(tp^2)+B3(4,4)*(tp^3);
		w(k,5)=B3(5,1)+B3(5,2)*tp+B3(5,3)*(tp^2)+B3(5,4)*(tp^3);
		w(k,6)=B3(6,1)+B3(6,2)*tp+B3(6,3)*(tp^2)+B3(6,4)*(tp^3);
	end      
	if t>=(t2+t3+t4) & t<(t2+t3+t4+t5)
		tp=t-t2-t3-t4;
		vrijeme(k,1)=t;
		w(k,1)=B4(1,1)+B4(1,2)*tp+B4(1,3)*(tp^2)+B4(1,4)*(tp^3);
		w(k,2)=B4(2,1)+B4(2,2)*tp+B4(2,3)*(tp^2)+B4(2,4)*(tp^3);
		w(k,3)=B4(3,1)+B4(3,2)*tp+B4(3,3)*(tp^2)+B4(3,4)*(tp^3);
		w(k,4)=B4(4,1)+B4(4,2)*tp+B4(4,3)*(tp^2)+B4(4,4)*(tp^3);
		w(k,5)=B4(5,1)+B4(5,2)*tp+B4(5,3)*(tp^2)+B4(5,4)*(tp^3);
		w(k,6)=B4(6,1)+B4(6,2)*tp+B4(6,3)*(tp^2)+B4(6,4)*(tp^3);
	end
	if t>=(t2+t3+t4+t5) & t<(t2+t3+t4+t5+t6)
		tp=t-t2-t3-t4-t5;
		vrijeme(k,1)=t;
		w(k,1)=B5(1,1)+B5(1,2)*tp+B5(1,3)*(tp^2)+B5(1,4)*(tp^3);
		w(k,2)=B5(2,1)+B5(2,2)*tp+B5(2,3)*(tp^2)+B5(2,4)*(tp^3);
		w(k,3)=B5(3,1)+B5(3,2)*tp+B5(3,3)*(tp^2)+B5(3,4)*(tp^3);
		w(k,4)=B5(4,1)+B5(4,2)*tp+B5(4,3)*(tp^2)+B5(4,4)*(tp^3);
		w(k,5)=B5(5,1)+B5(5,2)*tp+B5(5,3)*(tp^2)+B5(5,4)*(tp^3);
		w(k,6)=B5(6,1)+B5(6,2)*tp+B5(6,3)*(tp^2)+B5(6,4)*(tp^3);
	end
	if t>=(t2+t3+t4+t5+t6) & t<(t2+t3+t4+t5+t6+t7+dt*0.01)
		tp=t-t2-t3-t4-t5-t6;
		vrijeme(k,1)=t;
		w(k,1)=B6(1,1)+B6(1,2)*tp+B6(1,3)*(tp^2)+B6(1,4)*(tp^3)+B6(1,5)*(tp^4);
		w(k,2)=B6(2,1)+B6(2,2)*tp+B6(2,3)*(tp^2)+B6(2,4)*(tp^3)+B6(2,5)*(tp^4);
		w(k,3)=B6(3,1)+B6(3,2)*tp+B6(3,3)*(tp^2)+B6(3,4)*(tp^3)+B6(3,5)*(tp^4);
		w(k,4)=B6(4,1)+B6(4,2)*tp+B6(4,3)*(tp^2)+B6(4,4)*(tp^3)+B6(4,5)*(tp^4);
		w(k,5)=B6(5,1)+B6(5,2)*tp+B6(5,3)*(tp^2)+B6(5,4)*(tp^3)+B6(5,5)*(tp^4);
		w(k,6)=B6(6,1)+B6(6,2)*tp+B6(6,3)*(tp^2)+B6(6,4)*(tp^3)+B6(6,5)*(tp^4);
	end
	k=k+1;
	t=t+dt;
end
t=0;
k=1;
while t<(Tuk+dt*0.01)
	wpom=(w(k,:))';
	qpom=f0(wpom,a1,a2);
	q(k,:)=qpom';
	k=k+1;
	t=t+dt;
end
clear wpom qpom;
figure(1)
set(gcf, 'Name', 'Vremenska ovisnost varijabli zglobova')
plot(vrijeme,q(:,1),'r-',vrijeme,q(:,2),'b--',vrijeme,q(:,3),'y:')
title('1. zglob ------- (crveno)   2. zglob -- -- -- -- (plavo)   3. zglob - - - - - (�uto) ')
xlabel('Vrijeme [s]')
ylabel('Varijable zglobova [rad]')
grid on
vrijemews=vrijeme;
qws=q;
save 'rez1ws' vrijemews qws;
clear vrijemews qws;
disp('Za slijede�i grafi�ki prikaz pritisnite tipku')
pause

disp(' ')
disp(' ')
disp('GRAFI�KI PRIKAZ VREMENSKIH OVISNOSTI BRZINA ZGLOBOVA')
disp('        ZA TROOSNI PLANARNI ROTACIJSKI ROBOT        ')
disp(' ')
disp(' ')
t=0;
k=1;
qstari=q(k,:);
t=t+dt;
k=k+1;
kk=k-1;
clear vrijeme;
while t<(Tuk+dt*0.01)
	vrijeme(kk,:)=t;
	qnovi=q(k,:);
	dq(kk,:)=(qnovi-qstari)/dt;
	qstari=qnovi;
	kk=kk+1;
	k=k+1;
	t=t+dt;
end
clear qnovi qstari kk;
figure(2)
set(gcf, 'Name', 'Vremenska ovisnost brzina zglobova')
plot(vrijeme, dq(:,1), 'r-', vrijeme, dq(:,2), 'b--', vrijeme, dq(:,3), 'y:')
title('1. zglob ------- (crveno)   2. zglob -- -- -- -- (plavo)   3. zglob - - - - - (�uto) ')
xlabel('Vrijeme [s]')
ylabel('Brzine zglobova [rad/s]')
grid on
vrijemews=vrijeme;
brzinews=dq;
save 'rez2ws' vrijemews brzinews;
clear vrijemews brzinews;
disp('Za slijede�i grafi�ki prikaz pritisnite tipku')
pause

disp(' ')
disp(' ')
disp('GRAFI�KI PRIKAZ VREMENSKIH OVISNOSTI UBRZANJA ZGLOBOVA')
disp('         ZA TROOSNI PLANARNI ROTACIJSKI ROBOT         ')
disp(' ')
disp('Samo trenutak  molim')
t=0;
k=1;
dqstari=dq(k,:);
t=t+dt;
k=k+1;
kk=k-1;
clear vrijeme;
while t<(Tuk-dt*0.01)
	vrijeme(kk,:)=t;
	dqnovi=dq(k,:);
	ddq(kk,:)=(dqnovi-dqstari)/dt;
	dqstari=dqnovi;
	kk=kk+1;
	k=k+1;
	t=t+dt;
end
clear dqnovi dqstari kk;
figure(3)
set(gcf, 'Name', 'Vremenska ovisnost ubrzanja zglobova');
plot(vrijeme, ddq(:,1), 'r-', vrijeme, ddq(:,2), 'b--', vrijeme, ddq(:,3), 'y:' ) 
title('1. zglob ------- (crveno)   2. zglob -- -- -- -- (plavo)   3. zglob - - - - - (�uto) ')
xlabel('Vrijeme [s]')
ylabel('Ubrzanja zglobova [rad/s^2]')
grid on
vrijemews=vrijeme;
ubrzanjaws=ddq;
save 'rez3ws' vrijemews ubrzanjaws;
clear vrijemews ubrzanjaws;
disp('Za slijede�i grafi�ki prikaz pritisnite tipku')
pause

disp(' ')
disp(' ')
disp('      GRAFI�KI PRIKAZ ZADANIH TO�AKA ,      ')
disp('�ELJENE I APROKSIMIRANE PUTANJE U XY RAVNINI')
disp('    ZA TROOSNI PLANARNI ROTACIJSKI ROBOT    ')
disp(' ')
disp(' ')
if krug==0
	t=0;
	k=1;
	while t<(Tuk+dt*0.01)
		if t>=0 & t<t2
			tp=t;
			wxz(k,1)=(w2(1,1)-w1(1,1))*(tp^2)/(t2^2)+w1(1,1);
			wyz(k,1)=(w2(2,1)-w1(2,1))*(tp^2)/(t2^2)+w1(2,1);
		end
		if t>=t2 & t<(t2+t3)
			tp=t-t2;
			wxz(k,1)=(w3(1,1)-w2(1,1))*tp/t3+w2(1,1);
			wyz(k,1)=(w3(2,1)-w2(2,1))*tp/t3+w2(2,1);
		end
		if t>=(t2+t3) & t<(t2+t3+t4)
			tp=t-t2-t3;
			wxz(k,1)=(w4(1,1)-w3(1,1))*tp/t4+w3(1,1);
			wyz(k,1)=(w4(2,1)-w3(2,1))*tp/t4+w3(2,1);
		end      
		if t>=(t2+t3+t4) & t<(t2+t3+t4+t5)
			tp=t-t2-t3-t4;
			wxz(k,1)=(w5(1,1)-w4(1,1))*tp/t5+w4(1,1);
			wyz(k,1)=(w5(2,1)-w4(2,1))*tp/t5+w4(2,1);
		end
		if t>=(t2+t3+t4+t5) & t<(t2+t3+t4+t5+t6)
			tp=t-t2-t3-t4-t5;
			wxz(k,1)=(w6(1,1)-w5(1,1))*tp/t6+w5(1,1);
			wyz(k,1)=(w6(2,1)-w5(2,1))*tp/t6+w5(2,1);
		end
		if t>=(t2+t3+t4+t5+t6) & t<(t2+t3+t4+t5+t6+t7+dt*0.01)
			tp=t-t2-t3-t4-t5-t6;
			tps=2*(t2+t3+t4+t5+t6);
			wxz(k,1)=(w7(1,1)-w6(1,1))*tp*(tp+tps)/(t7*(t7+tps))+w6(1,1);
			wyz(k,1)=(w7(2,1)-w6(2,1))*tp*(tp+tps)/(t7*(t7+tps))+w6(2,1);
		end
		t=t+dt;
		k=k+1;
	end
end
if krug==1
	t=0;
	k=1;
	while t<(Tuk+dt*0.01)
		if t>=0 & t<t2
			tp=t;
			wxz(k,1)=r*sin(2*pi*(t^2)/(Tuk*t2))+xs;
			wyz(k,1)=r*cos(2*pi*(t^2)/(Tuk*t2))+ys;
		end
		if t>=t2 & t<(t2+t3)
			tp=t-t2;
			wxz(k,1)=r*sin(2*pi*t/Tuk)+xs;
			wyz(k,1)=r*cos(2*pi*t/Tuk)+ys;
		end
		if t>=(t2+t3) & t<(t2+t3+t4)
			tp=t-t2-t3;
			wxz(k,1)=r*sin(2*pi*t/Tuk)+xs;
			wyz(k,1)=r*cos(2*pi*t/Tuk)+ys;
		end      
		if t>=(t2+t3+t4) & t<(t2+t3+t4+t5)
			tp=t-t2-t3-t4;
			wxz(k,1)=r*sin(2*pi*t/Tuk)+xs;
			wyz(k,1)=r*cos(2*pi*t/Tuk)+ys;
		end
		if t>=(t2+t3+t4+t5) & t<(t2+t3+t4+t5+t6)
			tp=t-t2-t3-t4-t5;
			wxz(k,1)=r*sin(2*pi*t/Tuk)+xs;
			wyz(k,1)=r*cos(2*pi*t/Tuk)+ys;
		end
		if t>=(t2+t3+t4+t5+t6) & t<(t2+t3+t4+t5+t6+t7+dt*0.01)
			tp=t-t2-t3-t4-t5-t6;
			tps=2*(t2+t3+t4+t5+t6);
			wxz(k,1)=r*sin(2*pi*(t^2)/(Tuk*(t7+tps))+pi*tps/(t7+tps))+xs;
			wyz(k,1)=r*cos(2*pi*(t^2)/(Tuk*(t7+tps))+pi*tps/(t7+tps))+ys;
		end
		t=t+dt;
		k=k+1;
	end
end
wx(:,1)=wxz(:,1);
wy(:,1)=wyz(:,1);
wx(:,2)=w(:,1);
wy(:,2)=w(:,2);
figure(4)
set(gcf, 'Name', 'Prikaz zadanih to�aka, �eljene i aproksimirane putanje')
plot(w1(1), w1(2), 'cx', w2(1), w2(2), 'cx', w3(1), w3(2), 'cx', w4(1), w4(2), 'cx', ...
	w5(1), w5(2), 'cx', w6(1), w6(2), 'cx', w7(1), w7(2), 'cx')
axis ('equal')
hold on
plot(wx(:,1), wy(:,1), 'y--', wx(:,2), wy(:,2), 'r-' )
title('�eljena (�uto, -- -- -- --) i aproksimirana (crveno, -------- ) trajektorija')
xlabel('x - os [m]')
ylabel('y - os [m]')
grid off
hold off
xtoc=[w1(1,1) w2(1,1) w3(1,1) w4(1,1) w5(1,1) w6(1,1) w7(1,1)];
ytoc=[w1(2,1) w2(2,1) w3(2,1) w4(2,1) w5(2,1) w6(2,1) w7(2,1)];
wxws=wx;
wyws=wy;
save 'rez4ws' xtoc ytoc wxws wyws;
clear wxws wyws;
clear;