function Bi = f5(v1,v2,dv1,dv2,ti)
%Bi = f5(v1,v2,dv1,dv2,ti)
% Funkcija za generiranje matrica B2,...,B5
%Varijabla v: q ili w (vektor varijabli zglobova ili
%vektor konfiguracije alata)

vki=[v1 v2 dv1 dv2];
pom1=[1 0 0 0]';  pom2=[0 0 1 0]';
pom3=[-3/(ti^2) 3/(ti^2) -2/ti -1/ti]';
pom4=[2/(ti^3) -2/(ti^3) 1/(ti^2) 1/(ti^2)]';
tki=[pom1 pom2 pom3 pom4]; 
Bi=vki*tki;

