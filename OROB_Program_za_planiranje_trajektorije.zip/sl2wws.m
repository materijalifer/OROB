%Procedura sl2wws: usporedba zakreta zglobova pri planiranju trajektorije u prostoru
%konfiguracije alata s jednim maksimumom na trajektoriji i maksimumima na svakom
%segmentu trajektorije

disp(' ')
disp(' ')
disp('     USPOREDBA METODA PLANIRANJA TRAJEKTORIJE     ')
disp('          U PROSTORU KONFIGURACIJE ALATA            ')
disp('PRI �EMU SU MAKSIMUMI KUTNIH BRZINA ILI UBRZANJA :')
disp('(1) DOZVOLJENI NA SAMO JEDNOM MJESTU TRAJEKTORIJE ')
disp('(2) DOZVOLJENI NA SVAKOM SEGMENTU TRAJEKTORIJE    ')
disp(' ')
disp(' ')
disp('GRAFI�KI PRIKAZ VREMENSKE OVISNOSTI VARIJABLI ZGLOBOVA')
disp('         ZA TROOSNI PLANARNI ROTACIJSKI ROBOT         ')
disp(' ')
clear
disp(' ')
load 'rez1w'
load 'rez1ws'

hold off
figure (2)
set(gcf, 'Name', 'w - prostor: 1 maksimum, maksimumi na segmentima');
plot(vrijemew, qw(:,1), 'y-', vrijemew, qw(:,2), 'r-', vrijemew, qw(:,3), 'b-')
xlabel('Vrijeme [s]')
ylabel('Zakreti [rad]')
title('w: ______  ws:__  __  __   1. zglob: �uto   2. zglob: crveno   3. zglob: plavo')
hold on
plot(vrijemews, qws(:,1), 'y--', vrijemews, qws(:,2), 'r--', vrijemews, qws(:,3), 'b--')
clear 

