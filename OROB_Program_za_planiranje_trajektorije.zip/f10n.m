function S3 = f10n(mdq,mddq,vgr,agr)
% S3 = f10n(mdq,mddq,vgr,agr)
% Funkcija za tra�enje faktora normiranja Sv, Sa i S

pom1=(mdq(1,1))/(vgr(1,1));
pom2=(mdq(2,1))/(vgr(2,1));
pom3=(mdq(3,1))/(vgr(3,1));
Sv=pom1;
if pom2>Sv, Sv=pom2; end
if pom3>Sv, Sv=pom3; end
pom4=sqrt((mddq(1,1))/(agr(1,1)));
pom5=sqrt((mddq(2,1))/(agr(2,1)));
pom6=sqrt((mddq(3,1))/(agr(3,1)));
Sa=pom4;
if pom5>Sa, Sa=pom5; end
if pom6>Sa, Sa=pom6; end
maxs=Sv;
if Sa>maxs, maxs=Sa; end
S3=[Sv Sa maxs];

