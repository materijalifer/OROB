function mddqi = f10(Bi,ti)
% mddqi = f10(Bi,ti)
% Funkcija za trazenje maksimuma akceleracija 
% na segmentima od drugog do petog
% ddq2(t),...,ddq5(t)

B2i=Bi(:,3); B3i=Bi(:,4);
t=0; 
dt=ti/100; 
maxi=[0 0 0]'; 
mini=[0 0 0]';
while t < (ti+dt-dt*0.000001)
	ddqi=2*B2i+6*B3i*t;
	for j=1:3
		if ddqi(j,1) > maxi(j,1), maxi(j,1)=ddqi(j,1); end
		if ddqi(j,1) < mini(j,1), mini(j,1)=ddqi(j,1); end
	end 
	t=t+dt; 
end
for j=1:3
	if maxi(j,1) > (mini(j,1))*(-1)
 		mddqi(j,1)=maxi(j,1);
	else 
		mddqi(j,1)=(mini(j,1))*(-1); 
	end
end

