%Procedura ulazdato: U�itava ulazne podatke iz datoteke

datoteka = input('Ime datoteke s ulaznim podacima: ', 's');
eval(['load ' datoteka])