%Procedura sl4qw: usporedba ubrzanja zglobova pri planiranju trajektorije u prostoru
%varijabli zglobova i prostoru konfiguracije alata pri �emu su maksimumi
%kutnih brzina ili ubrzanja dozvoljeni na samo jednom mjestu trajektorije

disp(' ')
disp(' ')
disp('          USPOREDBA METODA PLANIRANJA TRAJEKTORIJE          ')
disp('U PROSTORU VARIJABLI ZGLOBOVA I PROSTORU KONFIGURACIJE ALATA')
disp('      PRI �EMU SU MAKSIMUMI KUTNIH BRZINA ILI UBRZANJA      ')
disp('       DOZVOLJENI NA SAMO JEDNOM MJESTU TRAJEKTORIJE        ')
disp(' ')
disp(' ')
disp('GRAFI�KI PRIKAZ VREMENSKE OVISNOSTI UBRZANJA ZGLOBOVA')
disp('         ZA TROOSNI PLANARNI ROTACIJSKI ROBOT         ')
disp(' ')
clear
disp(' ')
load 'rez3q'
load 'rez3w'

hold off
figure (4)
set(gcf, 'Name', 'Usporedba: w - prostor, q - prostor, maximum na trajektoriji');
plot(vrijemeq, ubrzanjaq(:,1), 'y-', vrijemeq, ubrzanjaq(:,2), 'r-', vrijemeq, ubrzanjaq(:,3), 'b-')
xlabel('Vrijeme [s]')
ylabel('Ubrzanja [rad/s^2]')
title('q: ______  w:__  __  __   1. zglob: �uto   2. zglob: crveno   3. zglob: plavo')
hold on
plot(vrijemew, ubrzanjaw(:,1), 'y--', vrijemew, ubrzanjaw(:,2), 'r--', vrijemew, ubrzanjaw(:,3), 'b--')
clear 