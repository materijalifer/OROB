%Procedura sl1qsws: Usporedba isplaniranih trajektorija u prostoru
%varijabli zglobova i prostoru konfiguracije alata pri �emu su maksimumi
%kutnih brzina uli ubrzanja dozvoljeni na svakom segmentu trajektorije

disp(' ')
disp(' ')
disp('          USPOREDBA METODA PLANIRANJA TRAJEKTORIJE          ')
disp('U PROSTORU VARIJABLI ZGLOBOVA I PROSTORU KONFIGURACIJE ALATA')
disp('      PRI �EMU SU MAKSIMUMI KUTNIH BRZINA ILI UBRZANJA      ')
disp('       DOZVOLJENI NA SVAKOM SEGMENTU TRAJEKTORIJE        ')
disp(' ')
disp(' ')
disp('      GRAFI�KI PRIKAZ ZADANIH TO�AKA,      ')
disp('�ELJENE I APROKSIMIRANE PUTANJE U XY RAVNINI')
disp('    ZA TROOSNI PLANARNI ROTACIJSKI ROBOT    ')
disp(' ')
clear
disp(' ')
load 'rez4qs'
load 'rez4ws';
wx(:,1)=wxqs(:,1); wx(:,2)=wxqs(:,2); wx(:,3)=wxws(:,2);
wy(:,1)=wyqs(:,1); wy(:,2)=wyqs(:,2); wy(:,3)=wyws(:,2);

%Prvi stupac matrice wx: Niz �eljenih x koordinata kod planiranja u prostoru varijabli
%zglobova (a iste bi trebale biti i kod planiranja u prostoru konfiguracije alata, ina�e
%usporedba nema smisla)
%Drugi stupac matrice wx: Niz x koordinata isplaniranih u prostoru varijabli zglobova
%Tre�i stupac matrice wx: Niz x koordinata isplaniranih u prostoru konfiguracije alata
%Sli�no matrica wy

figure(1);
set(gcf, 'Name', 'Usporedba: w - prostor, q - prostor, maximumi na segmentimai');
plot(xtoc(1), ytoc(1), 'cx', xtoc(2), ytoc(2), 'cx', xtoc(3), ytoc(3), 'cx', xtoc(4), ytoc(4), 'cx', ...
	xtoc(5), ytoc(5), 'cx', xtoc(6), ytoc(6), 'cx', xtoc(7), ytoc(7), 'cx')
hold on 
plot(wx(:,1), wy(:,1), 'y:', wx(:,2), wy(:,2), 'b--', wx(:,3), wy(:,3), 'r-')
axis('equal')
grid off
xlabel('x - os')
ylabel('y - os')
title('�eljeno: _  _  _(�uto)   q - prostor: __  __  __ (plavo)   w - prostor: ______ (crveno)')
clear 


