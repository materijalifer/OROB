%Procedura za planiranje i usporedbu trajektorija za troosni
%planarni rotacijski robot

%U path stavlja direktorij trajekto u kojem se nalaze potrebne datoteke:
path(path, 'c:\matlab\toolbox\matlab\trajekto')

izbor = menu('Odaberite:', 'Planiranje trajektorije', 'Usporedba isplaniranih trajektorija');
if izbor == 1
	planira
else
	uspored
end