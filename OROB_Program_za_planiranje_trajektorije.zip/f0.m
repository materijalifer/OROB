function  qi = f0(wi,a1,a2)
% qi = f0(wi,a1,a2)
% Funkcija za rje�avanje inverznog kinemati�kog problema
% Vra�a vektor varijabli zglobova qi na osnovu vektora
% konfiguracije alata wi i duljina segmenata a1 i a2

wi1=wi(1,1); wi2=wi(2,1); wi6=wi(6,1);
qi2=acos((wi1*wi1+wi2*wi2-a1*a1-a2*a2)/(2*a1*a2));
pom1=(a1+a2*cos(qi2))*wi2-a2*sin(qi2)*wi1;
pom2=(a1+a2*cos(qi2))*wi1+a2*sin(qi2)*wi2;
qi1=atan2(pom1,pom2); qi3=pi*log(wi6);
qi=[qi1 qi2 qi3]'; 
