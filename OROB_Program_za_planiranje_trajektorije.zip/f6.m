function B6 = f6(v6,v7,dv6,dv7,t7)
%B6 = f6(v6,v7,dv6,dv7,t7)
% Funkcija za generiranje matrice B6
%Varijabla v: q ili w (vektor varijabli zglobova ili
%vektor konfiguracije alata)

vk6=[v6 v7 dv6 dv7];
pom1=[1 0 0 0]';  pom2=[0 0 1 0]';
pom3=[-6/(t7^2) 6/(t7^2) -3/t7 0]';
pom4=[8/(t7^3) -8/(t7^3) 3/(t7^2) 0]';
pom5=[-3/(t7^4) 3/(t7^4) -1/(t7^3) 0]';
tk6=[pom1 pom2 pom3 pom4 pom5];
 B6=vk6*tk6;

