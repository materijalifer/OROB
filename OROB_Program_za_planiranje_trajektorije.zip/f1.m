function ti = f1(v1,v2)
%ti = f1(v1,v2)
%Funkcija za ra�unanje parametri�kih vremena t2,...,t7
%varijabla v: q ili w (vektor varijabli zglobova ili 
%vektor konfiguracije alata)

ti = sqrt(sum((v2-v1).*(v2-v1)));


