%Procedura radq

disp(' ')
disp(' ')
disp('INTERPOLACIJA PUTANJE U PROSTORU VARIJABLI ZGLOBOVA')
disp('       POLINOMIMA TRE�EG I �ETVRTOG STUPNJA        ')
disp('       ZA TROOSNI PLANARNI ROTACIJSKI ROBOT        ')
disp(' PRI �EMU SU MAKSIMUMI KUTNIH BRZINA ILI UBRZANJA  ')
disp('   DOZVOLJENI NA SAMO JEDNOM MJESTU TRAJEKTORIJE   ')
disp(' ');
disp('Zadane varijable :')
disp(' ')
disp('duljine segmenata ([m]) :'), a1, a2, d3
disp(' ') 
disp('To�ke pomo�u vektora konfiguracije alata :')
w1, w2, w3, w4, w5, w6, w7
disp(' ')
 disp('Ograni�enja brzina zglobova ([rad*s^(-1)]) :'), vgr
disp(' ') 
disp('ogranicenja ubrzanja zglobova ([rad*s^(-2)]) :'), agr
disp(' ') 
disp('Crtanje kruga (krug=0 NE i krug=1 DA) :'), krug

if krug==1
	disp(' ') 
	disp('Polumjer kruga ([m]) :'), r
	disp(' '); disp('sredi�te kruga ([m]) :'), xs, ys, 
end

disp(' ') 
disp(' ')
disp('RJE�AVANJE INVERZNOG KINEMATI�KOG PROBLEMA')
disp('  TROOSNOG PLANARNOG ROTACIJSKOG ROBOTA   ')
disp(' ') 
disp('Kori�tena funkcija:') , help f0
disp(' ') 
disp('Zadane to�ke u prostoru varijabli zglobova ([rad]) :')
q1=f0(w1,a1,a2), q2=f0(w2,a1,a2), q3=f0(w3,a1,a2), q4=f0(w4,a1,a2)
q5=f0(w5,a1,a2), q6=f0(w6,a1,a2), q7=f0(w7,a1,a2)

disp(' ') 
disp(' ')
disp('PLANIRANJE TRAJEKTORIJE U PROSTORU VARIJABLI ZGLOBOVA')
disp('        ZA TROOSNI PLANARNI ROTACIJSKI ROBOT         ')
disp('  PRI �EMU SU MAKSIMUMI KUTNIH BRZINA ILI UBRZANJA   ')
disp('    DOZVOLJENI NA SAMO JEDNOM MJESTU TRAJEKTORIJE    ')
disp(' ') 
disp('Koritene funkcije:')
help f1, help f2, help f3, help f4 
help f5, help f6, help f7, help f8 
help f9, help f10, help f11, help f12
disp(' ') 
disp('Ra�unanje parametri�kih vremena:')
t2=f1(q1,q2), t3=f1(q2,q3), t4=f1(q3,q4)
t5=f1(q4,q5), t6=f1(q5,q6), t7=f1(q6,q7)

i=1; 
S=0;
while abs(1-S) > 1e-10 
	disp(' ') 
	disp('Broj iteracije:'), i
	disp(' ')
	M = f2(t2,t3,t4,t5,t6,t7)
	A=f3(q1,q2,q3,q4,q5,q6,q7,t2,t3,t4,t5,t6,t7)
	disp(' ') 
	disp('Brzine u zadanim to�kama ([rad/s]) :')
	dq=A*inv(M); 
	dq1=[0 0 0]' 
	dq2=dq(:,1) 
	dq3=dq(:,2)
	dq4=dq(:,3)
	 dq5=dq(:,4) 
	dq6=dq(:,5) 
	dq7=[0 0 0]'
	disp(' ') 
	disp('Koeficijenti za 1. segment:')
	B1 = f4(q1,q2,dq1,dq2,t2)
	disp(' ') 
	disp('Koeficijenti za 2. segment:')
	B2=f5(q2,q3,dq2,dq3,t3)
	disp(' ') 
	disp('Koeficijenti za 3. segment:')
	B3=f5(q3,q4,dq3,dq4,t4)
     	disp(' ') 
	disp('Koeficijenti za 4. segment:')
	B4=f5(q4,q5,dq4,dq5,t5)
	disp(' ') 
	disp('Koeficijenti za 5. segment:')
	B5=f5(q5,q6,dq5,dq6,t6)
	disp(' ') 
	disp('Koeficijenti za 6. segment:')
	B6=f6(q6,q7,dq6,dq7,t7)
	disp(' ') 
	disp('Maksimumi kutnih brzina ([rad*s^(-1)]):')
	mdq1=f7(B1,t2), mdq2=f8(B2,t3), mdq3=f8(B3,t4)
	mdq4=f8(B4,t5), mdq5=f8(B5,t6), mdq6=f7(B6,t7)
	disp(' ') 
	disp('Maksimumi kutnih ubrzanja ([rad*s^(-2)]):')
	mddq1=f9(B1,t2), mddq2=f10(B2,t3), mddq3=f10(B3,t4)
	mddq4=f10(B4,t5), mddq5=f10(B5,t6), mddq6=f9(B6,t7), disp(' ')
	disp('Ukupni maksimum kutnih brzina ([rad*s^(-1)]):')
     	mdq=f11(mdq1,mdq2,mdq3,mdq4,mdq5,mdq6) 
	disp(' ')
	disp('Ukupni maksimum kutnih ubrzanja ([rad*s^(-2)]):')
	mddq=f11(mddq1,mddq2,mddq3,mddq4,mddq5,mddq6)
	disp(' ') 
	disp('Ograni�enja brzine ([rad*s(-1)]):'), vgr
	disp(' ') 
	disp('Ograni�enja ubrzanja ([rad*s^(-2)]):'), agr
	S3=f12(mdq,mddq,vgr,agr);
	disp(' ')
	disp('Faktor normiranja po brzini:'), Sv=S3(1,1)
	disp(' ')
	disp('Faktor normiranja po ubrzanju:'), Sa=S3(1,2)
	disp(' ')
	disp('Ukupni faktor normiranja:'), S=S3(1,3)
	disp(' ') 
	disp('Nova vremena prijelaza segmenata ([s]):')
     	t2=t2*S, t3=t3*S, t4=t4*S, t5=t5*S, t6=t6*S, t7=t7*S
	disp(' ')
	disp('Ukupno vrijeme ([s]):')
	Tuk=t2+t3+t4+t5+t6+t7 
	i =i+1;
end
i=i-1;
disp(' ') 
disp('Broj iteracija potrebnih za zavr�etak postupka:'), i
disp(' ') 
disp('Putanja se prelazi za slijede�i broj sekundi:'), Tuk
disp(' ')
disp(' ')
disp('Za grafi�ke prikaze pritisnite tipku')
pause

disp(' ') 
disp(' ')
disp('GRAFI�KI PRIKAZ VREMENSKE OVISNOSTI VARIJABLI ZGLOBOVA')
disp('         ZA TROOSNI PLANARNI ROTACIJSKI ROBOT         ')
disp(' ') 
t=0; 
k=1; 
Tuk=t2+t3+t4+t5+t6+t7; 
dt=Tuk/300;
while t < (Tuk+dt*0.01)
	if t>=0 & t<t2
		tp=t; 
		vrijeme(k,1)=t;
		q(k,1)=B1(1,1)+B1(1,2)*tp+B1(1,3)*(tp^2)+B1(1,4)*(tp^3)+B1(1,5)*(tp^4);
		q(k,2)=B1(2,1)+B1(2,2)*tp+B1(2,3)*(tp^2)+B1(2,4)*(tp^3)+B1(2,5)*(tp^4);
		q(k,3)=B1(3,1)+B1(3,2)*tp+B1(3,3)*(tp^2)+B1(3,4)*(tp^3)+B1(3,5)*(tp^4);
	end
     	if t>=t2 & t<(t2+t3)
		tp=t-t2; 
		vrijeme(k,1)=t;
		q(k,1)=B2(1,1)+B2(1,2)*tp+B2(1,3)*(tp^2)+B2(1,4)*(tp^3);
		q(k,2)=B2(2,1)+B2(2,2)*tp+B2(2,3)*(tp^2)+B2(2,4)*(tp^3);
		q(k,3)=B2(3,1)+B2(3,2)*tp+B2(3,3)*(tp^2)+B2(3,4)*(tp^3);
	end
	if t>=(t2+t3) & t<(t2+t3+t4)
		tp=t-t2-t3; 
		vrijeme(k,1)=t;
		q(k,1)=B3(1,1)+B3(1,2)*tp+B3(1,3)*(tp^2)+B3(1,4)*(tp^3);
		q(k,2)=B3(2,1)+B3(2,2)*tp+B3(2,3)*(tp^2)+B3(2,4)*(tp^3);
		q(k,3)=B3(3,1)+B3(3,2)*tp+B3(3,3)*(tp^2)+B3(3,4)*(tp^3); 
	end      
	if t>=(t2+t3+t4) & t<(t2+t3+t4+t5)
		tp=t-t2-t3-t4; 
		vrijeme(k,1)=t;
		q(k,1)=B4(1,1)+B4(1,2)*tp+B4(1,3)*(tp^2)+B4(1,4)*(tp^3);
		q(k,2)=B4(2,1)+B4(2,2)*tp+B4(2,3)*(tp^2)+B4(2,4)*(tp^3);
		q(k,3)=B4(3,1)+B4(3,2)*tp+B4(3,3)*(tp^2)+B4(3,4)*(tp^3);
	end
	if t>=(t2+t3+t4+t5) & t<(t2+t3+t4+t5+t6)
		tp=t-t2-t3-t4-t5; 
		vrijeme(k,1)=t;
		q(k,1)=B5(1,1)+B5(1,2)*tp+B5(1,3)*(tp^2)+B5(1,4)*(tp^3);
		q(k,2)=B5(2,1)+B5(2,2)*tp+B5(2,3)*(tp^2)+B5(2,4)*(tp^3);
		q(k,3)=B5(3,1)+B5(3,2)*tp+B5(3,3)*(tp^2)+B5(3,4)*(tp^3);
	end
	if t>=(t2+t3+t4+t5+t6) & t<(t2+t3+t4+t5+t6+t7+dt*0.01)
		tp=t-t2-t3-t4-t5-t6; 
		vrijeme(k,1)=t;
		q(k,1)=B6(1,1)+B6(1,2)*tp+B6(1,3)*(tp^2)+B6(1,4)*(tp^3)+B6(1,5)*(tp^4);
		q(k,2)=B6(2,1)+B6(2,2)*tp+B6(2,3)*(tp^2)+B6(2,4)*(tp^3)+B6(2,5)*(tp^4);
		q(k,3)=B6(3,1)+B6(3,2)*tp+B6(3,3)*(tp^2)+B6(3,4)*(tp^3)+B6(3,5)*(tp^4);
	end
	k=k+1; 
	t=t+dt; 
end
figure(1)
set(gcf, 'Name', 'Vremenska ovisnost varijabli zglobova')
plot(vrijeme,q(:,1),'r-',vrijeme,q(:,2),'b--',vrijeme,q(:,3),'y:')
title('1. zglob ------- (crveno)   2. zglob -- -- -- -- (plavo)   3. zglob - - - - - (�uto) ')
xlabel('Vrijeme [s]')
ylabel('Varijable zglobova [rad]')
grid on
vrijemeq=vrijeme; 
qq=q;
save rez1q vrijemeq qq; 
clear vrijemeq qq;
disp('Za slijede�i grafi�ki prikaz pritisnite tipku')
pause

disp(' ') 
disp(' ')
disp('GRAFI�KI PRIKAZ VREMENSKIH OVISNOSTI BRZINA ZGLOBOVA')
disp('        ZA TROOSNI PLANARNI ROTACIJSKI ROBOT        ')
disp(' ')
t=0; 
k=1;
while t<(Tuk+dt*0.01)
	if t>=0 & t<t2 
		tp=t;
		brzine(k,1)=B1(1,2)+2*B1(1,3)*tp+3*B1(1,4)*(tp^2)+4*B1(1,5)*(tp^3);
		brzine(k,2)=B1(2,2)+2*B1(2,3)*tp+3*B1(2,4)*(tp^2)+4*B1(2,5)*(tp^3);
		brzine(k,3)=B1(3,2)+2*B1(3,3)*tp+3*B1(3,4)*(tp^2)+4*B1(3,5)*(tp^3);
	end
	if t>=t2 & t<(t2+t3) 
		tp=t-t2;
		brzine(k,1)=B2(1,2)+2*B2(1,3)*tp+3*B2(1,4)*(tp^2);
		brzine(k,2)=B2(2,2)+2*B2(2,3)*tp+3*B2(2,4)*(tp^2);
		brzine(k,3)=B2(3,2)+2*B2(3,3)*tp+3*B2(3,4)*(tp^2);
	end
	if t>=(t2+t3) & t<(t2+t3+t4) 
		tp=t-t2-t3;
		brzine(k,1)=B3(1,2)+2*B3(1,3)*tp+3*B3(1,4)*(tp^2);
		brzine(k,2)=B3(2,2)+2*B3(2,3)*tp+3*B3(2,4)*(tp^2);
		brzine(k,3)=B3(3,2)+2*B3(3,3)*tp+3*B3(3,4)*(tp^2);
	end
	if t>=(t2+t3+t4) & t<(t2+t3+t4+t5) 
		tp=t-t2-t3-t4;
		brzine(k,1)=B4(1,2)+2*B4(1,3)*tp+3*B4(1,4)*(tp^2);
		brzine(k,2)=B4(2,2)+2*B4(2,3)*tp+3*B4(2,4)*(tp^2);
		brzine(k,3)=B4(3,2)+2*B4(3,3)*tp+3*B4(3,4)*(tp^2);
	end
	if t>=(t2+t3+t4+t5) & t<(t2+t3+t4+t5+t6)
		tp=t-t2-t3-t4-t5;
		brzine(k,1)=B5(1,2)+2*B5(1,3)*tp+3*B5(1,4)*(tp^2);
		brzine(k,2)=B5(2,2)+2*B5(2,3)*tp+3*B5(2,4)*(tp^2);
		brzine(k,3)=B5(3,2)+2*B5(3,3)*tp+3*B5(3,4)*(tp^2);
	end
	if t>=(t2+t3+t4+t5+t6) & t<(t2+t3+t4+t5+t6+t7+dt*0.01)
		tp=t-t2-t3-t4-t5-t6;
		brzine(k,1)=B6(1,2)+2*B6(1,3)*tp+3*B6(1,4)*(tp^2)+4*B6(1,5)*(tp^3);
		brzine(k,2)=B6(2,2)+2*B6(2,3)*tp+3*B6(2,4)*(tp^2)+4*B6(2,5)*(tp^3);
		brzine(k,3)=B6(3,2)+2*B6(3,3)*tp+3*B6(3,4)*(tp^2)+4*B6(3,5)*(tp^3);
	end
	k=k+1; 
	t=t+dt; 
end
figure(2)
set(gcf, 'Name', 'Vremenska ovisnost brzina zglobova')
plot(vrijeme, brzine(:,1), 'r-', vrijeme, brzine(:,2), 'b--', vrijeme, brzine(:,3), 'y:')
title('1. zglob ------- (crveno)   2. zglob -- -- -- -- (plavo)   3. zglob - - - - - (�uto) ')
xlabel('Vrijeme [s]')
ylabel('Brzine zglobova [rad/s]')
grid on
vrijemeq=vrijeme; 
brzineq=brzine;
save rez2q vrijemeq brzineq; 
clear vrijemeq brzineq;
disp('Za slijede�i grafi�ki prikaz pritisnite tipku')
pause

disp(' ') 
disp(' ')
disp('GRAFI�KI PRIKAZ VREMENSKIH OVISNOSTI UBRZANJA ZGLOBOVA');
disp('         ZA TROOSNI PLANARNI ROTACIJSKI ROBOT         ');
disp(' ') 
disp(' ')
t=0; 
k=1;
while t<(Tuk+dt*0.01)
	if t>=0 & t<t2 
		tp=t;
		ubrzanja(k,1)=2*B1(1,3)+6*B1(1,4)*tp+12*B1(1,5)*(tp^2);
		ubrzanja(k,2)=2*B1(2,3)+6*B1(2,4)*tp+12*B1(2,5)*(tp^2);
		ubrzanja(k,3)=2*B1(3,3)+6*B1(3,4)*tp+12*B1(3,5)*(tp^2);
	end
	if t>=t2 & t<(t2+t3) 
		tp=t-t2;
		ubrzanja(k,1)=2*B2(1,3)+6*B2(1,4)*tp;
		ubrzanja(k,2)=2*B2(2,3)+6*B2(2,4)*tp;
		ubrzanja(k,3)=2*B2(3,3)+6*B2(3,4)*tp;
	end
	if t>=(t2+t3) & t<(t2+t3+t4) 
		tp=t-t2-t3;
		ubrzanja(k,1)=2*B3(1,3)+6*B3(1,4)*tp;
		ubrzanja(k,2)=2*B3(2,3)+6*B3(2,4)*tp;
		ubrzanja(k,3)=2*B3(3,3)+6*B3(3,4)*tp;
	end
	if t>=(t2+t3+t4) & t<(t2+t3+t4+t5)
		tp=t-t2-t3-t4;
		ubrzanja(k,1)=2*B4(1,3)+6*B4(1,4)*tp;
		ubrzanja(k,2)=2*B4(2,3)+6*B4(2,4)*tp;
		ubrzanja(k,3)=2*B4(3,3)+6*B4(3,4)*tp;
	end
	if t>=(t2+t3+t4+t5) & t<(t2+t3+t4+t5+t6)
		tp=t-t2-t3-t4-t5;
		ubrzanja(k,1)=2*B5(1,3)+6*B5(1,4)*tp;
		ubrzanja(k,2)=2*B5(2,3)+6*B5(2,4)*tp;
		ubrzanja(k,3)=2*B5(3,3)+6*B5(3,4)*tp;
	end
     	if t>=(t2+t3+t4+t5+t6) & t<(t2+t3+t4+t5+t6+t7+dt*0.01)
		tp=t-t2-t3-t4-t5-t6;
		ubrzanja(k,1)=2*B6(1,3)+6*B6(1,4)*tp+12*B6(1,5)*(tp^2);
		ubrzanja(k,2)=2*B6(2,3)+6*B6(2,4)*tp+12*B6(2,5)*(tp^2);
		ubrzanja(k,3)=2*B6(3,3)+6*B6(3,4)*tp+12*B6(3,5)*(tp^2);
	end
	k=k+1; 
	t=t+dt; 
end
figure(3)
set(gcf, 'Name', 'Vremenska ovisnost ubrzanja zglobova');
plot(vrijeme, ubrzanja(:,1), 'r-', vrijeme, ubrzanja(:,2), 'b--', vrijeme, ubrzanja(:,3), 'y:' ) 
title('1. zglob ------- (crveno)   2. zglob -- -- -- -- (plavo)   3. zglob - - - - - (�uto) ')
xlabel('Vrijeme [s]')
ylabel('Ubrzanja zglobova [rad/s^2]')
grid on
vrijemeq=vrijeme; 
ubrzanjaq=ubrzanja;
save rez3q vrijemeq ubrzanjaq; 
clear vrijemeq ubrzanjaq;
disp('Za slijede�i grafi�ki prikaz pritisnite tipku')
pause

disp(' ') 
disp(' ')
disp('      GRAFI�KI PRIKAZ ZADANIH TO�AKA ,      ')
disp('�ELJENE I APROKSIMIRANE PUTANJE U XY RAVNINI')
disp('    ZA TROOSNI PLANARNI ROTACIJSKI ROBOT    ')
disp(' ')
disp(' ')
if krug==0 
	t=0; 
	k=1;
	while t < (Tuk+dt*0.01)
		if t>=0 & t<t2
			tp=t;
			wxz(k,1)=(w2(1,1)-w1(1,1))*(tp^2)/(t2^2)+w1(1,1);
			wyz(k,1)=(w2(2,1)-w1(2,1))*(tp^2)/(t2^2)+w1(2,1);
		end
		if t >= t2 & t<(t2+t3) 
			tp=t-t2;
			wxz(k,1)=(w3(1,1)-w2(1,1))*tp/t3+w2(1,1);
			wyz(k,1)=(w3(2,1)-w2(2,1))*tp/t3+w2(2,1);
		end
		if t>=(t2+t3) & t<(t2+t3+t4)
			tp=t-t2-t3;
			wxz(k,1)=(w4(1,1)-w3(1,1))*tp/t4+w3(1,1);
			wyz(k,1)=(w4(2,1)-w3(2,1))*tp/t4+w3(2,1);
		end
		if t>=(t2+t3+t4) &  t<(t2+t3+t4+t5) 
			tp=t-t2-t3-t4;
			wxz(k,1)=(w5(1,1)-w4(1,1))*tp/t5+w4(1,1);
			wyz(k,1)=(w5(2,1)-w4(2,1))*tp/t5+w4(2,1);
		end
		if t>=(t2+t3+t4+t5) & t<(t2+t3+t4+t5+t6)
			tp=t-t2-t3-t4-t5;
			wxz(k,1)=(w6(1,1)-w5(1,1))*tp/t6+w5(1,1);
			wyz(k,1)=(w6(2,1)-w5(2,1))*tp/t6+w5(2,1);
		end
		if t>=(t2+t3+t4+t5+t6) & t<(t2+t3+t4+t5+t6+t7+dt*0.01)
			tp=t-t2-t3-t4-t5-t6; 
			tps=2*(t2+t3+t4+t5+t6);
			wxz(k,1)=(w7(1,1)-w6(1,1))*tp*(tp+tps)/(t7*(t7+tps))+w6(1,1);
			wyz(k,1)=(w7(2,1)-w6(2,1))*tp*(tp+tps)/(t7*(t7+tps))+w6(2,1);
		end
	t=t+dt;  
	k=k+1; 
	end
end
if krug==1 
	t=0; 
	k=1;
	while t<(Tuk+dt*0.01)
		if t>=0 & t<t2 
			tp=t;
			wxz(k,1)=r*sin(2*pi*(t^2)/(Tuk*t2))+xs;
			wyz(k,1)=r*cos(2*pi*(t^2)/(Tuk*t2))+ys;
		end
		if t>=t2 & t<(t2+t3) 
			tp=t-t2;
			wxz(k,1)=r*sin(2*pi*t/Tuk)+xs;
			wyz(k,1)=r*cos(2*pi*t/Tuk)+ys;
		end
		if t>=(t2+t3) & t<(t2+t3+t4) 
			tp=t-t2-t3;
			wxz(k,1)=r*sin(2*pi*t/Tuk)+xs;
			wyz(k,1)=r*cos(2*pi*t/Tuk)+ys;
		end
		if t>=(t2+t3+t4) & t<(t2+t3+t4+t5) 
			tp=t-t2-t3-t4;
			wxz(k,1)=r*sin(2*pi*t/Tuk)+xs;
			wyz(k,1)=r*cos(2*pi*t/Tuk)+ys;
		end
		if t>=(t2+t3+t4+t5) & t<(t2+t3+t4+t5+t6)
			tp=t-t2-t3-t4-t5;
			wxz(k,1)=r*sin(2*pi*t/Tuk)+xs;
			wyz(k,1)=r*cos(2*pi*t/Tuk)+ys;
		end
		if t>=(t2+t3+t4+t5+t6) & t<(t2+t3+t4+t5+t6+t7+dt*0.01)
			tp=t-t2-t3-t4-t5-t6; 
			tps=2*(t2+t3+t4+t5+t6);
			wxz(k,1)=r*sin(2*pi*(t^2)/(Tuk*(t7+tps))+pi*tps/(t7+tps))+xs;
			wyz(k,1)=r*cos(2*pi*(t^2)/(Tuk*(t7+tps))+pi*tps/(t7+tps))+ys;
		end
		t=t+dt; 
		k=k+1; 
	end 
end
%Prvi stupac matrice wx: x koordinate zami�ljene trajektorije:
wx(:,1)=wxz(:,1); 
%Prvi stupac matrice wy: y koordinate zami�ljene trajektorije:
wy(:,1)=wyz(:,1);
t=0; 
k=1;
while t<(Tuk+dt*0.01)
	w(k,1)=a1*cos(q(k,1))+a2*cos(q(k,1)+q(k,2));
	w(k,2)=a1*sin(q(k,1))+a2*sin(q(k,1)+q(k,2));
	w(k,3)=d3;
	w(k,4)=0;
	w(k,5)=0;
	w(k,6)=exp(q(k,3)/pi);
	k=k+1; 
	t=t+dt; 
end
%Drugi stupac matrice wx: x koordinate isplanirane trajektorije:
wx(:,2)=w(:,1); 
%Drugi stupac matrice wy: y koordinate isplanirane trajektorije:
wy(:,2)=w(:,2);
figure(4)
set(gcf, 'Name', 'Prikaz zadanih to�aka, �eljene i aproksimirane putanje')
plot(w1(1), w1(2), 'cx', w2(1), w2(2), 'cx', w3(1), w3(2), 'cx', w4(1), w4(2), 'cx', ...
	w5(1), w5(2), 'cx', w6(1), w6(2), 'cx', w7(1), w7(2), 'cx')
axis ('equal')
hold on
plot(wx(:,1), wy(:,1), 'y--', wx(:,2), wy(:,2), 'r-' )
title('�eljena (�uto, -- -- -- --) i aproksimirana (crveno, -------- ) trajektorija')
xlabel('x - os [m]')
ylabel('y - os [m]')
grid off
hold off
xtoc=[w1(1,1) w2(1,1) w3(1,1) w4(1,1) w5(1,1) w6(1,1) w7(1,1)];
ytoc=[w1(2,1) w2(2,1) w3(2,1) w4(2,1) w5(2,1) w6(2,1) w7(2,1)];
wxq=wx; 
wyq=wy; 

%Sprema: x i y koordinate zadanih to�aka, niz x koordinata zami�ljene (prvi stupac wxq) i isplanirane
%trajektorije (drugi stupac wxq), niz y koordinata zami�ljene (prvi stupac wyq) i 
%isplanirane trajektorije (drugi stupac wyq)
save 'rez4q' xtoc ytoc wxq wyq; 
clear wxq wyq;

clear;
