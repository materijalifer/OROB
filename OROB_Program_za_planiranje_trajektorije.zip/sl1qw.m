%Procedura sl1qw: Usporedba isplaniranih trajektorija u prostoru
%varijabli zglobova i prostoru konfiguracije alata pri �emu su maksimumi
%kutnih brzina uli ubrzanja dozvoljeni na samo jednom mjestu trajektorije

disp(' ')
disp(' ')
disp('          USPOREDBA METODA PLANIRANJA TRAJEKTORIJE          ')
disp('U PROSTORU VARIJABLI ZGLOBOVA I PROSTORU KONFIGURACIJE ALATA')
disp('      PRI �EMU SU MAKSIMUMI KUTNIH BRZINA ILI UBRZANJA      ')
disp('       DOZVOLJENI NA SAMO JEDNOM MJESTU TRAJEKTORIJE        ')
disp(' ')
disp(' ')
disp('      GRAFI�KI PRIKAZ ZADANIH TO�AKA,      ')
disp('�ELJENE I APROKSIMIRANE PUTANJE U XY RAVNINI')
disp('    ZA TROOSNI PLANARNI ROTACIJSKI ROBOT    ')
disp(' ')
disp('Samo trenutak  molim')
clear
disp(' ')
load 'rez4q'
load 'rez4w';
wx(:,1)=wxq(:,1); wx(:,2)=wxq(:,2); wx(:,3)=wxw(:,2);
wy(:,1)=wyq(:,1); wy(:,2)=wyq(:,2); wy(:,3)=wyw(:,2);

%Prvi stupac matrice wx: Niz �eljenih x koordinata kod planiranja u prostoru varijabli
%zglobova (a iste bi trebale biti i kod planiranja u prostoru konfiguracije alata, ina�e
%usporedba nema smisla)
%Drugi stupac matrice wx: Niz x koordinata isplaniranih u prostoru varijabli zglobova
%Tre�i stupac matrice wx: Niz x koordinata isplaniranih u prostoru konfiguracije alata
%Sli�no matrica wy

figure(1);
set(gcf, 'Name', 'Usporedba: w - prostor, q - prostor, maximum na trajektoriji');
plot(xtoc(1), ytoc(1), 'cx', xtoc(2), ytoc(2), 'cx', xtoc(3), ytoc(3), 'cx', xtoc(4), ytoc(4), 'cx', ...
	xtoc(5), ytoc(5), 'cx', xtoc(6), ytoc(6), 'cx', xtoc(7), ytoc(7), 'cx')
hold on 
plot(wx(:,1), wy(:,1), 'y:', wx(:,2), wy(:,2), 'b--', wx(:,3), wy(:,3), 'r-')
axis('equal')
grid off
xlabel('x - os')
ylabel('y - os')
title('�eljeno: _  _  _(�uto)   q - prostor: __  __  __ (plavo)   w - prostor: ______ (crveno)')
clear 

