%Procedura sl2qw: usporedba zakreta zglobova pri planiranju trajektorije u prostoru
%varijabli zglobova i prostoru konfiguracije alata pri �emu su maksimumi
%kutnih brzina ili ubrzanja dozvoljeni na samo jednom mjestu trajektorije

disp(' ')
disp(' ')
disp('          USPOREDBA METODA PLANIRANJA TRAJEKTORIJE          ')
disp('U PROSTORU VARIJABLI ZGLOBOVA I PROSTORU KONFIGURACIJE ALATA')
disp('      PRI �EMU SU MAKSIMUMI KUTNIH BRZINA ILI UBRZANJA      ')
disp('       DOZVOLJENI NA SAMO JEDNOM MJESTU TRAJEKTORIJE        ')
disp(' ')
disp(' ')
disp('GRAFI�KI PRIKAZ VREMENSKE OVISNOSTI VARIJABLI ZGLOBOVA')
disp('         ZA TROOSNI PLANARNI ROTACIJSKI ROBOT         ')
disp(' ')
clear
disp(' ')
load 'rez1q'
load 'rez1w'

hold off
figure (2)
set(gcf, 'Name', 'Usporedba: w - prostor, q - prostor, maximum na trajektoriji');
plot(vrijemeq, qq(:,1), 'y-', vrijemeq, qq(:,2), 'r-', vrijemeq, qq(:,3), 'b-')
xlabel('Vrijeme [s]')
ylabel('Zakreti [rad]')
title('q: ______  w:__  __  __   1. zglob: �uto   2. zglob: crveno   3. zglob: plavo')
hold on
plot(vrijemew, qw(:,1), 'y--', vrijemew, qw(:,2), 'r--', vrijemew, qw(:,3), 'b--')
clear 