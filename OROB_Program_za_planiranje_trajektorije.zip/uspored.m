%Procedura uspored: pokretanje usporedbi isplaniranih trajektorija

izbor = get(popupmenuUsporedba,'Value');
%Bri�e i zatvara grafi�ki prozor:
clf reset;
close;

if izbor == 1
	sl1qw
	pause
	sl2qw
	pause
	sl3qw
	pause
	sl4qw
elseif izbor == 2
	sl1qsws
	pause
	sl2qsws
	pause
	sl3qsws
	pause
	sl4qsws
elseif izbor == 3
	sl1qqs
	pause
	sl2qqs
	pause
	sl3qqs
	pause
	sl4qqs
elseif izbor == 4
	sl1wws
	pause
	sl2wws
	pause
	sl3wws
	pause
	sl4wws
end


