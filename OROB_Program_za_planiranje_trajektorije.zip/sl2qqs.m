%Procedura sl2qqs: usporedba zakreta zglobova pri planiranju trajektorije u prostoru
%varijabli zglobova s jednim maksimumom na trajektoriji i maksimumima na svakom
%segmentu trajektorije

disp(' ')
disp(' ')
disp('     USPOREDBA METODA PLANIRANJA TRAJEKTORIJE     ')
disp('          U PROSTORU VARIJABLI ZGLOBOVA           ')
disp('PRI �EMU SU MAKSIMUMI KUTNIH BRZINA ILI UBRZANJA :')
disp('(1) DOZVOLJENI NA SAMO JEDNOM MJESTU TRAJEKTORIJE ')
disp('(2) DOZVOLJENI NA SVAKOM SEGMENTU TRAJEKTORIJE    ')
disp(' ')
disp(' ')
disp('GRAFI�KI PRIKAZ VREMENSKE OVISNOSTI VARIJABLI ZGLOBOVA')
disp('         ZA TROOSNI PLANARNI ROTACIJSKI ROBOT         ')
disp(' ')
clear
disp(' ')
load 'rez1q'
load 'rez1qs'

hold off
figure (2)
set(gcf, 'Name', 'q - prostor: 1 maksimum, maksimumi na segmentima');
plot(vrijemeq, qq(:,1), 'y-', vrijemeq, qq(:,2), 'r-', vrijemeq, qq(:,3), 'b-')
xlabel('Vrijeme [s]')
ylabel('Zakreti [rad]')
title('q: ______  qs:__  __  __   1. zglob: �uto   2. zglob: crveno   3. zglob: plavo')
hold on
plot(vrijemeqs, qqs(:,1), 'y--', vrijemeqs, qqs(:,2), 'r--', vrijemeqs, qqs(:,3), 'b--')
clear 
